create
    definer = root@localhost procedure getAllProducts()
BEGIN
select * from products;
END;

